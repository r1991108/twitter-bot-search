import json
import os
from requests_oauthlib import OAuth1Session
from datetime import datetime, timedelta, timezone

import boto3
sns_client = boto3.client('sns')
ssm_client = boto3.client('ssm')

oauth = None

def lambda_handler(event, context): 
    init()
    
    now_jst = datetime.now(timezone(timedelta(hours=+9), 'JST'))
    now_jst_str = now_jst.strftime('%Y年%-m月%-d日')
    tweet_text = 'おはようございます、今日は ' + now_jst_str + ' です。'
    
    now = datetime.now()
    key_word = '花火大会'     # 検索対象を設定する
    start_time = (datetime.now() + timedelta(hours=-1)).strftime('%Y-%m-%dT%H:%M:00Z')  # Lambda関数実行時間の一時間前 
    end_time = datetime.now().strftime('%Y-%m-%dT%H:%M:00Z')                            # Lambda関数実行時間の一分前
    count = count_matching_tweets(key_word, start_time, end_time)
    
    # twitter へ検索結果を投稿する
    tweet_text = tweet_text + '過去1時間内の「' + key_word +'」関連のツイートは ' + str(count) + ' 件でした。'
    tweet(tweet_text)
    
    # SNS へ検索結果を送信する
    sns_client.publish(
        TopicArn='arn:aws:sns:ap-northeast-1:XXXXXXXXXX:TwitterBotTopic', # SNS トピックのARNに置換する
        Subject='Twitter Bot からの連絡',
        Message=tweet_text
    )


def init():
    response = ssm_client.get_parameter(
        Name='/credentials/twitter',
        WithDecryption=True
    )
    twitter_parameters = json.loads(response['Parameter']['Value'])

    consumer_key = twitter_parameters['consumer_key']
    client_secret = twitter_parameters['client_secret']
    access_token = twitter_parameters['access_token']
    access_token_secret = twitter_parameters['access_token_secret']
    
    global oauth
    oauth = OAuth1Session(consumer_key, client_secret, access_token, access_token_secret)
        
def tweet(text):
    payload = {'text': text}
    response = oauth.post(
        'https://api.twitter.com/2/tweets',
        json=payload,
    )
    if response.status_code != 201:
        raise Exception(
            '[Error] {} {}'.format(response.status_code, response.text)
        )
        
def count_matching_tweets(search_word, start_time, end_time):

    url = 'https://api.twitter.com/2/tweets/search/recent'
    params = {
        'query': search_word,
        'max_results': 100,
        'start_time': start_time,
        'end_time': end_time
    }
    response = oauth.get(
       url, params=params
    )
    json_response = response.json()
    
    # print(json_response)
    
    if response.status_code != 200:
        raise Exception(
            '[Error] {} {}'.format(response.status_code, response.text)
        )

    return json_response['meta']['result_count']